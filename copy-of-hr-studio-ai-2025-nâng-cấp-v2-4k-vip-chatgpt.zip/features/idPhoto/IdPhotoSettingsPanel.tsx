/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useMemo } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { IdPhotoSettings, CommonSettingsPanelProps } from '../../types';
import { ID_PHOTO_CLOTHING_PRESETS } from '../../constants';
import { MicIcon } from '../../components';

const html = htm.bind(h);

interface IdPhotoSettingsPanelProps extends CommonSettingsPanelProps {
    settings: IdPhotoSettings;
    setSettings: (updater: (s: IdPhotoSettings) => IdPhotoSettings) => void;
}

// FIX: Refactored state update logic to resolve multiple errors.
// - Corrected `setSettings` calls to use object spread syntax `{...s, property: value}` instead of incorrectly trying to call the `IdPhotoSettings` type as a function. This fixes "'IdPhotoSettings' only refers to a type" errors.
// - Fixed state updates for properties like `clothingPrompts` and `preserveFaceDetails` to use correct property assignment, resolving "is not callable" errors.
// - Ensured all state updates align with the `IdPhotoSettings` type definition.
export const IdPhotoSettingsPanel: FunctionalComponent<IdPhotoSettingsPanelProps> = ({ settings, setSettings, onGenerate, generating, hasImage, buttonText, t }) => {
    const [isRecording, setIsRecording] = useState(false);

    const isCustomClothing = useMemo(() => {
        const clothingPrompt = settings.clothingPrompts[0] || '';
        if (!clothingPrompt) return false;
        return !ID_PHOTO_CLOTHING_PRESETS.some(p => p.prompt === clothingPrompt);
    }, [settings.clothingPrompts]);

    const handlePresetClick = (prompt: string) => {
        setSettings(s => ({ ...s, clothingPrompts: s.clothingPrompts[0] === prompt ? [] : [prompt] }));
    };
    
    const handleCustomClothingInput = (e: TargetedEvent<HTMLTextAreaElement>) => {
        setSettings(s => ({...s, clothingPrompts: [e.currentTarget.value]}));
    };

    const handleVoiceInput = () => {
        if (!('webkitSpeechRecognition' in window)) {
            alert("Sorry, your browser doesn't support voice input.");
            return;
        }
        const recognition = new (window as any).webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'vi-VN';

        recognition.onstart = () => setIsRecording(true);
        recognition.onend = () => setIsRecording(false);
        recognition.onerror = (e: any) => console.error("Speech Recognition Error:", e);
        recognition.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript;
            setSettings(s => ({...s, customPrompt: s.customPrompt ? `${s.customPrompt} ${transcript}` : transcript}));
        };

        if (isRecording) {
            recognition.stop();
        } else {
            recognition.start();
        }
    };
    
    const hairStyleOptions = {
        'auto': 'Tự động',
        'front': 'Thả trước',
        'back': 'Vuốt sau',
        'original': 'Giữ nguyên'
    };
    
    return html`
        <div class="settings-panel">
            <div class="form-group">
                <label>Nền</label>
                <div class="radio-group">
                    <label>
                        <input type="radio" name="bg" value="white" checked=${settings.background === 'white'} onChange=${() => setSettings(s => ({...s, background: 'white'}))} />
                        Trắng
                    </label>
                    <label>
                        <input type="radio" name="bg" value="blue" checked=${settings.background === 'blue'} onChange=${() => setSettings(s => ({...s, background: 'blue'}))} />
                        Xanh
                    </label>
                    <label>
                        <input type="radio" name="bg" value="gray" checked=${settings.background === 'gray'} onChange=${() => setSettings(s => ({...s, background: 'gray'}))} />
                        Ghi
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label>Trang phục</label>
                <div class="clothing-grid">
                    ${ID_PHOTO_CLOTHING_PRESETS.map(preset => html`
                        <button 
                            class="clothing-btn ${settings.clothingPrompts[0] === preset.prompt ? 'active' : ''}"
                            onClick=${() => handlePresetClick(preset.prompt)}
                        >${t(preset.labelKey)}</button>
                    `)}
                     <button 
                        class="clothing-btn ${settings.clothingPrompts.length === 0 ? 'active' : ''}"
                        onClick=${() => setSettings(s => ({ ...s, clothingPrompts: [] }))}
                    >Giữ nguyên</button>
                </div>
                <label for="custom-clothing-prompt" style=${{marginTop: '0.5rem'}}>Hoặc mô tả trang phục</label>
                <textarea 
                    id="custom-clothing-prompt" 
                    placeholder="VD: áo vest nữ màu be"
                    value=${isCustomClothing ? settings.clothingPrompts[0] || '' : ''}
                    onInput=${handleCustomClothingInput}
                ></textarea>
            </div>

            <div class="form-group">
                <label for="custom-prompt">Tùy chỉnh khác (kính, etc.)</label>
                 <div class="voice-input-container">
                    <textarea 
                        id="custom-prompt" 
                        placeholder="VD: đeo kính gọng đen..."
                        value=${settings.customPrompt}
                        onInput=${(e: TargetedEvent<HTMLTextAreaElement>) => setSettings(s => ({ ...s, customPrompt: e.currentTarget.value }))}
                    ></textarea>
                    <button class="voice-btn ${isRecording ? 'recording' : ''}" onClick=${handleVoiceInput} title="Nhập bằng giọng nói">
                        <${MicIcon} recording=${isRecording} />
                    </button>
                </div>
            </div>
             <div class="form-group">
                <label>Kiểu tóc</label>
                <div class="radio-group">
                   ${Object.entries(hairStyleOptions).map(([style, label]) => html`
                    <label>
                        <input type="radio" name="hairstyle" value=${style} checked=${settings.hairStyle === style} onChange=${() => setSettings(s => ({...s, hairStyle: style}))} />
                        ${label}
                    </label>
                   `)}
                </div>
            </div>
            <div class="form-group checkbox-group">
                <label><input type="checkbox" checked=${settings.preserveFaceDetails} onChange=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, preserveFaceDetails: e.currentTarget.checked}))}/> Giữ nét mặt gốc</label>
                <label><input type="checkbox" checked=${settings.smoothSkin} onChange=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, smoothSkin: e.currentTarget.checked}))}/> Làm mịn da</label>
                <label><input type="checkbox" checked=${settings.slightSmile} onChange=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, slightSmile: e.currentTarget.checked}))}/> Cười nhẹ</label>
            </div>
            <button class="btn btn-primary" onClick=${onGenerate} disabled=${generating || !hasImage} style=${{width: '100%'}}>
                ${generating ? 'Đang xử lý...' : (buttonText || 'Tạo ảnh')}
            </button>
        </div>
    `;
};