/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useMemo, useRef } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { BackgroundSettings, CommonSettingsPanelProps } from '../../types';
import { MicIcon, UploadIcon, CloseIcon } from '../../components';
// FIX: Import BACKGROUND_LIGHTING_EFFECTS to populate the new checkbox UI.
import { BACKGROUND_LIGHTING_EFFECTS } from '../../constants';

const html = htm.bind(h);

interface BackgroundSettingsPanelProps extends CommonSettingsPanelProps {
    settings: BackgroundSettings;
    setSettings: (updater: (s: BackgroundSettings) => BackgroundSettings) => void;
    isBatch?: boolean;
}

export const BackgroundSettingsPanel: FunctionalComponent<BackgroundSettingsPanelProps> = ({ settings, setSettings, onGenerate, generating, hasImage, isBatch = false, t }) => {
    const [isRecording, setIsRecording] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleVoiceInput = () => {
        if (!('webkitSpeechRecognition' in window)) {
            alert("Trình duyệt không hỗ trợ nhập liệu giọng nói.");
            return;
        }
        const recognition = new (window as any).webkitSpeechRecognition();
        recognition.lang = 'vi-VN';
        recognition.onstart = () => setIsRecording(true);
        recognition.onend = () => setIsRecording(false);
        recognition.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript;
            setSettings(s => ({ ...s, prompt: s.prompt ? `${s.prompt} ${transcript}` : transcript }));
        };
        isRecording ? recognition.stop() : recognition.start();
    };

    const handleReferenceImageUpload = (e: TargetedEvent<HTMLInputElement>) => {
        const file = e.currentTarget.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (loadEvent) => {
                if (loadEvent.target) {
                    setSettings(s => ({ ...s, referenceImage: loadEvent.target!.result as string }));
                }
            };
            reader.readAsDataURL(file);
        }
    };

    // FIX: Add handler for multi-select lighting effects.
    const handleLightingEffectChange = (effectKey: string) => {
        setSettings(s => {
            const currentEffects = s.lightingEffects || [];
            const newEffects = currentEffects.includes(effectKey)
                ? currentEffects.filter(e => e !== effectKey) // remove
                : [...currentEffects, effectKey]; // add
            return { ...s, lightingEffects: newEffects };
        });
    };
    
    const canGenerate = useMemo(() => {
        return hasImage && (settings.prompt.trim() !== '' || settings.referenceImage !== null);
    }, [hasImage, settings.prompt, settings.referenceImage]);

    return html`
        <div class="settings-panel">
            <div class="form-group">
                <label for="bg-prompt">Mô tả nền (Text)</label>
                <div class="voice-input-container">
                    <textarea 
                        id="bg-prompt" 
                        placeholder="VD: một bãi biển nhiệt đới với cát trắng và biển xanh..."
                        value=${settings.prompt}
                        onInput=${(e: TargetedEvent<HTMLTextAreaElement>) => setSettings(s => ({ ...s, prompt: e.currentTarget.value }))}
                    ></textarea>
                    <button class="voice-btn ${isRecording ? 'recording' : ''}" onClick=${handleVoiceInput} title="Nhập bằng giọng nói">
                        <${MicIcon} recording=${isRecording} />
                    </button>
                </div>
            </div>

            <div class="form-group">
                <label>Ảnh tham chiếu (Reference)</label>
                <input type="file" ref=${fileInputRef} onChange=${handleReferenceImageUpload} accept="image/*" style=${{ display: 'none' }} />
                <div class="reference-uploader" onClick=${() => fileInputRef.current?.click()}>
                    ${settings.referenceImage ? html`
                        <img src=${settings.referenceImage} alt="Reference" class="reference-preview"/>
                        <button class="remove-reference-btn" onClick=${(e: MouseEvent) => { e.stopPropagation(); setSettings(s => ({ ...s, referenceImage: null })); }} title="Xóa ảnh tham chiếu"><${CloseIcon}/></button>
                    ` : html`
                        <div class="reference-placeholder">
                           <${UploadIcon} />
                           <span>Nhấp để tải lên</span>
                        </div>
                    `}
                </div>
            </div>

            {/* FIX: Replaced incorrect state update logic with correct inline handlers to resolve type errors. */}
            <div class="form-group">
                <label>Tùy chọn tư thế</label>
                <div class="radio-group">
                    <label>
                        <input type="radio" name="pose" value="keep" checked=${settings.keepPose} onChange=${() => setSettings(s => ({ ...s, keepPose: true }))} />
                        Giữ nguyên
                    </label>
                    <label>
                        <input type="radio" name="pose" value="change" checked=${!settings.keepPose} onChange=${() => setSettings(s => ({ ...s, keepPose: false }))} />
                        Thay đổi dáng
                    </label>
                </div>
            </div>

            {/* FIX: Replaced single-select dropdown for 'lightingEffect' with a multi-select checkbox group for 'lightingEffects' to match the type definition. */}
            <div class="form-group">
                <label>Hiệu ứng ánh sáng (có thể chọn nhiều)</label>
                <div class="suggestions-list" style=${{ maxHeight: '250px', overflowY: 'auto' }}>
                    ${Object.entries(BACKGROUND_LIGHTING_EFFECTS).map(([group, options]) => html`
                        <div class="suggestion-sub-category" style=${{marginBottom: '0.5rem'}}>
                            <h4>${t(group)}</h4>
                            <div class="checkbox-group" style=${{gap: '0.5rem', paddingLeft: '0.5rem'}}>
                                ${options.map(opt => html`
                                    <label>
                                        <input
                                            type="checkbox"
                                            checked=${settings.lightingEffects?.includes(opt.key)}
                                            onChange=${() => handleLightingEffectChange(opt.key)}
                                        />
                                        {/* FIX: Removed an invalid JSX-style comment from the htm template literal. This syntax is not supported by htm and was causing parsing errors. */}
                                        <span>${t(opt.labelKey)}</span>
                                    </label>
                                `)}
                            </div>
                        </div>
                    `)}
                </div>
            </div>
            
            ${!isBatch && html`
                <div class="form-group">
                    <label>Số lượng ảnh tạo</label>
                    <input type="number" min="1" max="3" class="number-input" value=${settings.numImages} onInput=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({ ...s, numImages: Math.max(1, Math.min(3, parseInt(e.currentTarget.value, 10))) }))} />
                </div>
            `}

            <button class="btn btn-primary" onClick=${onGenerate} disabled=${generating || !canGenerate} style=${{width: '100%'}}>
                ${generating ? 'Đang thay đổi...' : 'Tạo ảnh'}
            </button>
        </div>
    `;
};
