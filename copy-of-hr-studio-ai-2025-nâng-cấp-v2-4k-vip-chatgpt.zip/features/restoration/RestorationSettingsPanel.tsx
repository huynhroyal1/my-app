/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { RestorationSettings, CommonSettingsPanelProps } from '../../types';
import { MicIcon } from '../../components';

const html = htm.bind(h);

interface RestorationSettingsPanelProps extends CommonSettingsPanelProps {
    settings: RestorationSettings;
    setSettings: (updater: (s: RestorationSettings) => RestorationSettings) => void;
}

export const RestorationSettingsPanel: FunctionalComponent<RestorationSettingsPanelProps> = ({ settings, setSettings, onGenerate, generating, hasImage, buttonText }) => {
    const [isRecording, setIsRecording] = useState(false);

    const handleVoiceInput = () => {
        if (!('webkitSpeechRecognition' in window)) {
            alert("Xin lỗi, trình duyệt của bạn không hỗ trợ nhập liệu bằng giọng nói.");
            return;
        }
        const recognition = new (window as any).webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'vi-VN';

        recognition.onstart = () => setIsRecording(true);
        recognition.onend = () => setIsRecording(false);
        recognition.onerror = (e: any) => console.error("Speech Recognition Error:", e);
        recognition.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript;
            // FIX: Use 'advancedPrompt' instead of 'customPrompt' to match the RestorationSettings type.
            setSettings(s => ({...s, advancedPrompt: s.advancedPrompt ? `${s.advancedPrompt} ${transcript}` : transcript}));
        };

        if (isRecording) {
            recognition.stop();
        } else {
            recognition.start();
        }
    };

    return html`
        <div class="settings-panel">
            {/* FIX: Removed the 'Phông nền' (background) options as 'backgroundOption' does not exist on RestorationSettings type. */}

            {/* FIX: Replaced incorrect settings properties with correct ones from the RestorationSettings type ('colorize', 'highQuality', 'sharpenBackground', 'isVietnamese'). */}
            <div class="form-group checkbox-group">
                <label><input type="checkbox" checked=${settings.colorize} onChange=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, colorize: e.currentTarget.checked}))}/> Tô màu</label>
                <label><input type="checkbox" checked=${settings.highQuality} onChange=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, highQuality: e.currentTarget.checked}))}/> Chất lượng cao (xóa xước, tăng chi tiết)</label>
                <label><input type="checkbox" checked=${settings.sharpenBackground} onChange=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, sharpenBackground: e.currentTarget.checked}))}/> Làm nét nền & chủ thể</label>
                <label><input type="checkbox" checked=${settings.isVietnamese} onChange=${(e: TargetedEvent<HTMLInputElement>) => setSettings(s => ({...s, isVietnamese: e.currentTarget.checked}))}/> Người Việt Nam</label>
            </div>

            <div class="form-group">
                <label for="custom-prompt-restore">Prompt tùy chỉnh</label>
                 <div class="voice-input-container">
                    <textarea 
                        id="custom-prompt-restore" 
                        placeholder="VD: Xóa vết xước ở góc phải, làm rõ chi tiết áo..."
                        value=${settings.advancedPrompt}
                        onInput=${(e: TargetedEvent<HTMLTextAreaElement>) => setSettings(s => ({ ...s, advancedPrompt: e.currentTarget.value }))}
                    ></textarea>
                    <button class="voice-btn ${isRecording ? 'recording' : ''}" onClick=${handleVoiceInput} title="Nhập bằng giọng nói">
                        <${MicIcon} recording=${isRecording} />
                    </button>
                </div>
            </div>
            
            <button class="btn btn-primary" onClick=${onGenerate} disabled=${generating || !hasImage} style=${{width: '100%'}}>
                ${generating ? 'Đang phục chế...' : (buttonText || 'Phục chế ảnh')}
            </button>
        </div>
    `;
};
