/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { h, FunctionalComponent } from 'preact';
import { useState, useEffect } from 'preact/hooks';
import htm from 'htm';
import type { TargetedEvent } from 'preact/compat';
import { Theme } from '../../types';
// FIX: Removed unused import `testApiKey` to resolve export error, as API key management UI is being removed to comply with guidelines.

const html = htm.bind(h);

const SettingsInfo: FunctionalComponent = () => html`
    <div class="settings-info">
        <div class="info-card">
            <div class="info-card-header">
                <h3>Cách hoạt động</h3>
            </div>
            <p>
                Để đảm bảo tính bảo mật và cho phép bạn toàn quyền kiểm soát việc sử dụng, ứng dụng yêu cầu bạn cung cấp API Key của riêng bạn. Mọi yêu cầu xử lý ảnh sẽ được thực hiện thông qua key của bạn.
            </p>
        </div>
         <div class="info-card">
            <div class="info-card-header">
                <h3>Làm thế nào để lấy API Key?</h3>
            </div>
            <ul>
                <li><strong>Bước 1:</strong> Truy cập vào Google AI Studio.</li>
                <li><strong>Bước 2:</strong> Nhấp vào nút "Get API Key" (Lấy khóa API).</li>
                <li><strong>Bước 3:</strong> Tạo một khóa API mới trong dự án của bạn.</li>
                <li><strong>Bước 4:</strong> Sao chép khóa và dán vào ô bên trái.</li>
            </ul>
             <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" class="youtube-link">
                <span>Lấy API Key tại Google AI Studio</span>
            </a>
        </div>
    </div>
`;


interface SettingsAppProps {
    onClearCache: () => void;
    theme: Theme;
    setTheme: (theme: Theme) => void;
}

export const SettingsApp: FunctionalComponent<SettingsAppProps> = ({ onClearCache, theme, setTheme }) => {
    // FIX: Removed state and logic for API key input to align with guidelines requiring the key to be set via environment variables.
    // The UI for API key management has been removed.

    return html`
        <div class="settings-app-layout">
            <div class="settings-panel">
                <h2>Cài đặt</h2>
                 <div class="form-group">
                    <h3>Google Gemini API Key</h3>
                    <p class="settings-description">
                        Để sử dụng các tính năng AI, bạn cần cung cấp API Key của riêng mình từ Google.
                    </p>
                    {/* FIX: Removed API key input form and replaced it with an informational message. */}
                    <div class="api-status" style=${{marginBottom: '0.5rem', marginTop: '0.5rem'}}>
                        Trạng thái: API Key được định cấu hình an toàn trên máy chủ.
                    </div>
                </div>

                 <div class="form-group">
                    <h3>Giao diện</h3>
                    <p class="settings-description">
                        Chọn giao diện sáng hoặc tối cho ứng dụng.
                    </p>
                    <div class="radio-group">
                        <label>
                            {/* FIX: Corrected theme handling to align with the updated 'light' | 'dark' Theme type. */}
                            <input type="radio" name="theme" value="light" checked=${theme === 'light'} onChange=${() => setTheme('light')} />
                            Sáng
                        </label>
                        <label>
                            <input type="radio" name="theme" value="dark" checked=${theme === 'dark'} onChange=${() => setTheme('dark')} />
                            Tối
                        </label>
                    </div>
                </div>
                
                <div class="form-group">
                    <h3>Hệ thống</h3>
                    <button class="btn" onClick=${onClearCache} style=${{width: '100%', background: '#ff6b6b', color: 'white', marginTop: '0.5rem'}}>
                        🔄 Xóa Cache & Tải lại trang
                    </button>
                </div>
            </div>
             <${SettingsInfo} />
        </div>
    `;
};